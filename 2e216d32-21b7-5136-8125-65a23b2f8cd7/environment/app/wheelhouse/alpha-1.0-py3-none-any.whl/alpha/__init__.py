__version__ = "1.0"
import common
def a():
    return common.scale(2)
