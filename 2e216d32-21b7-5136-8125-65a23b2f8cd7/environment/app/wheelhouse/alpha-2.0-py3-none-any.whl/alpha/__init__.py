__version__ = "2.0"
import common
def a():
    return common.scale(3)
