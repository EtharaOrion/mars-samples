__version__ = "1.5"
VERSION = "1.5"
K = 5
def scale(x):
    return x * 10
