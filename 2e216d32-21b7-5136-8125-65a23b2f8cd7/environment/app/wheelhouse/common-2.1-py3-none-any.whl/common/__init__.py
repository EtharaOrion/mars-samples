__version__ = "2.1"
VERSION = "2.1"
K = 7
def scale(x):
    return x * 100
