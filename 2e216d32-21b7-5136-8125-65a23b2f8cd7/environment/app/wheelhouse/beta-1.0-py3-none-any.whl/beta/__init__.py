__version__ = "1.0"
import common
def b():
    return common.K + 1
