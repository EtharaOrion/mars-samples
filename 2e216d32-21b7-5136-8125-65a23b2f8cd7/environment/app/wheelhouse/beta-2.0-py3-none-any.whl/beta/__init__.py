__version__ = "2.0"
import common
def b():
    return common.K * 2
